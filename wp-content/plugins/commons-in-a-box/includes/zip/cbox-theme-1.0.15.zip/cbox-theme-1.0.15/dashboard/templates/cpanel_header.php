<div id="infinity-cpanel-header-version">
	<?php _e( 'Version:', infinity_text_domain ) ?> <?php print INFINITY_VERSION ?> ~
	<a id="infinity-cpanel-header-link" href="http://infinity.presscrew.com/" target="_blank">http://infinity.presscrew.com</a>
</div>
<div id="infinity-cpanel-header-logo"></div>